@extends('layouts.public')
@section('title', 'Rooms — Grand Horizon')
@section('content')
    <div class="max-w-6xl mx-auto px-6 py-12">
        <h1 class="font-display text-4xl font-semibold text-gray-900 mb-2">Our Rooms</h1>
        <p class="text-gray-500 mb-8">Choose from our selection of carefully appointed rooms</p>

        <form method="GET" class="flex flex-wrap gap-3 mb-8 bg-white p-4 rounded-xl border border-gray-100">
            <select name="type" class="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400">
                <option value="">All Types</option>
                @foreach(\App\Models\Room::types() as $type)
                    <option value="{{ $type }}" {{ request('type') == $type ? 'selected' : '' }}>{{ ucfirst($type) }}</option>
                @endforeach
            </select>
            <input type="number" name="min_price" value="{{ request('min_price') }}" placeholder="Min price"
                   class="border border-gray-200 rounded-lg px-3 py-2 text-sm w-28 focus:outline-none focus:ring-2 focus:ring-hotel-400">
            <input type="number" name="max_price" value="{{ request('max_price') }}" placeholder="Max price"
                   class="border border-gray-200 rounded-lg px-3 py-2 text-sm w-28 focus:outline-none focus:ring-2 focus:ring-hotel-400">
            <button type="submit" class="bg-hotel-600 hover:bg-hotel-700 text-white text-sm px-5 py-2 rounded-lg transition-colors">Filter</button>
            @if(request()->hasAny(['type','min_price','max_price']))
                <a href="{{ route('public.rooms') }}" class="border border-gray-200 text-gray-500 text-sm px-4 py-2 rounded-lg hover:bg-gray-50">Clear</a>
            @endif
        </form>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @forelse($rooms as $room)
                <a href="{{ route('public.room', $room) }}"
                   class="bg-white rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-all group overflow-hidden">
                    <div class="h-1.5 w-full {{ match($room->status) { 'available'=>'bg-green-400','occupied'=>'bg-red-400',default=>'bg-gray-300' } }}"></div>
                    <div class="p-5">
                        <div class="flex justify-between items-start mb-2">
                            <div>
                                <p class="text-xl font-bold text-gray-900">Room {{ $room->room_number }}</p>
                                <p class="text-xs text-gray-400 capitalize">{{ $room->type }} · Floor {{ $room->floor }} · Up to {{ $room->capacity }} guests</p>
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-hotel-700">${{ number_format($room->price_per_night, 0) }}</p>
                                <p class="text-xs text-gray-400">per night</p>
                            </div>
                        </div>
                        @if($room->description)
                            <p class="text-sm text-gray-500 my-3 line-clamp-2">{{ $room->description }}</p>
                        @endif
                        @if($room->amenities)
                            <div class="flex flex-wrap gap-1 mb-4">
                                @foreach(array_slice($room->amenities, 0, 4) as $amenity)
                                    <span class="bg-gray-100 text-gray-600 text-xs px-2 py-0.5 rounded">{{ $amenity }}</span>
                                @endforeach
                            </div>
                        @endif
                        <div class="flex items-center justify-between">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium {{ $room->status_badge }}">
                            {{ ucfirst($room->status) }}
                        </span>
                            @if($room->status === 'available')
                                <span class="text-sm text-hotel-600 font-medium group-hover:underline">Book →</span>
                            @endif
                        </div>
                    </div>
                </a>
            @empty
                <div class="col-span-full py-16 text-center text-gray-400">No rooms found matching your filters.</div>
            @endforelse
        </div>
        <div class="mt-6">{{ $rooms->links() }}</div>
    </div>
@endsection
