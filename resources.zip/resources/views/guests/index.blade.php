@extends('layouts.app')
@section('page-title', 'Guests')

@section('header-actions')
    <a href="{{ route('guests.create') }}"
       class="inline-flex items-center gap-2 bg-hotel-600 hover:bg-hotel-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
        Add Guest
    </a>
@endsection

@section('content')
    <!-- Search -->
    <form method="GET" class="flex gap-3 mb-6">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Search by name, email, phone or ID..."
               class="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400 w-72">
        <button type="submit" class="bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-medium px-4 py-2 rounded-lg transition-colors">Search</button>
        @if(request('search'))
            <a href="{{ route('guests.index') }}" class="bg-white border border-gray-200 text-gray-500 text-sm px-4 py-2 rounded-lg hover:bg-gray-50">Clear</a>
        @endif
    </form>

    <!-- Table -->
    <div class="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <table class="w-full text-sm">
            <thead>
            <tr class="border-b border-gray-100 bg-gray-50">
                <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Guest</th>
                <th class="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Contact</th>
                <th class="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Nationality</th>
                <th class="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Stays</th>
                <th class="px-4 py-3"></th>
            </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
            @forelse($guests as $guest)
                <tr class="hover:bg-gray-50 transition-colors">
                    <td class="px-6 py-3">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-full bg-hotel-100 flex items-center justify-center flex-shrink-0">
                                <span class="text-xs font-semibold text-hotel-700">{{ strtoupper(substr($guest->first_name, 0, 1) . substr($guest->last_name, 0, 1)) }}</span>
                            </div>
                            <div>
                                <p class="font-medium text-gray-900">{{ $guest->full_name }}</p>
                                @if($guest->id_number)
                                    <p class="text-xs text-gray-400">ID: {{ $guest->id_number }}</p>
                                @endif
                            </div>
                        </div>
                    </td>
                    <td class="px-4 py-3">
                        <p class="text-gray-700">{{ $guest->email }}</p>
                        <p class="text-xs text-gray-400">{{ $guest->phone }}</p>
                    </td>
                    <td class="px-4 py-3 text-gray-600">{{ $guest->nationality ?? '—' }}</td>
                    <td class="px-4 py-3">
                        <span class="font-medium text-gray-900">{{ $guest->reservations_count }}</span>
                        <span class="text-gray-400"> stays</span>
                    </td>
                    <td class="px-4 py-3 text-right">
                        <div class="flex items-center justify-end gap-2">
                            <a href="{{ route('guests.show', $guest) }}" class="text-xs text-hotel-600 hover:underline">View</a>
                            <a href="{{ route('guests.edit', $guest) }}" class="text-xs text-gray-500 hover:underline">Edit</a>
                            <a href="{{ route('reservations.create', ['guest_id' => $guest->id]) }}" class="text-xs text-green-600 hover:underline">Book</a>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="px-6 py-12 text-center text-gray-400">
                        <svg class="w-10 h-10 mx-auto mb-2 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>
                        </svg>
                        No guests found
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-4">{{ $guests->links() }}</div>
@endsection
