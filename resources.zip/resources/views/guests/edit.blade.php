@extends('layouts.app')
@section('page-title', $guest->full_name)
@section('breadcrumbs')
    <a href="{{ route('guests.index') }}" class="hover:text-gray-600">Guests</a> / {{ $guest->full_name }}
@endsection

@section('header-actions')
    <a href="{{ route('reservations.create', ['guest_id' => $guest->id]) }}"
       class="inline-flex items-center gap-2 bg-hotel-600 hover:bg-hotel-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
        New Reservation
    </a>
    <a href="{{ route('guests.edit', $guest) }}" class="inline-flex items-center gap-2 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 text-sm font-medium px-4 py-2 rounded-lg transition-colors">Edit</a>
@endsection

@section('content')
    <div class="grid grid-cols-3 gap-6">
        <!-- Profile Card -->
        <div class="col-span-1 space-y-4">
            <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-6">
                <div class="flex flex-col items-center text-center mb-5">
                    <div class="w-16 h-16 rounded-full bg-hotel-100 flex items-center justify-center mb-3">
                        <span class="text-xl font-bold text-hotel-700">{{ strtoupper(substr($guest->first_name, 0, 1) . substr($guest->last_name, 0, 1)) }}</span>
                    </div>
                    <h2 class="font-semibold text-gray-900 text-lg">{{ $guest->full_name }}</h2>
                    <p class="text-sm text-gray-500">{{ $guest->nationality ?? '' }}</p>
                </div>

                <dl class="space-y-3 text-sm">
                    <div>
                        <dt class="text-xs text-gray-400 uppercase tracking-wide mb-0.5">Email</dt>
                        <dd class="text-gray-900">{{ $guest->email }}</dd>
                    </div>
                    @if($guest->phone)
                        <div>
                            <dt class="text-xs text-gray-400 uppercase tracking-wide mb-0.5">Phone</dt>
                            <dd class="text-gray-900">{{ $guest->phone }}</dd>
                        </div>
                    @endif
                    @if($guest->id_number)
                        <div>
                            <dt class="text-xs text-gray-400 uppercase tracking-wide mb-0.5">ID / Passport</dt>
                            <dd class="text-gray-900">{{ $guest->id_number }}</dd>
                        </div>
                    @endif
                    @if($guest->date_of_birth)
                        <div>
                            <dt class="text-xs text-gray-400 uppercase tracking-wide mb-0.5">Date of Birth</dt>
                            <dd class="text-gray-900">{{ $guest->date_of_birth->format('M d, Y') }}</dd>
                        </div>
                    @endif
                    @if($guest->address || $guest->city || $guest->country)
                        <div>
                            <dt class="text-xs text-gray-400 uppercase tracking-wide mb-0.5">Address</dt>
                            <dd class="text-gray-900">{{ implode(', ', array_filter([$guest->address, $guest->city, $guest->country])) }}</dd>
                        </div>
                    @endif
                </dl>

                @if($guest->notes)
                    <div class="mt-4 pt-4 border-t border-gray-100">
                        <p class="text-xs text-gray-400 uppercase tracking-wide mb-1">Notes</p>
                        <p class="text-sm text-gray-600">{{ $guest->notes }}</p>
                    </div>
                @endif
            </div>

            <!-- Stats -->
            <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
                <div class="grid grid-cols-2 gap-4 text-center">
                    <div>
                        <p class="text-2xl font-bold text-gray-900">{{ $guest->total_stays }}</p>
                        <p class="text-xs text-gray-400">Completed Stays</p>
                    </div>
                    <div>
                        <p class="text-2xl font-bold text-hotel-700">${{ number_format($guest->total_spent, 0) }}</p>
                        <p class="text-xs text-gray-400">Total Spent</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Reservations History -->
        <div class="col-span-2">
            <div class="bg-white rounded-xl border border-gray-100 shadow-sm">
                <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                    <h3 class="font-semibold text-gray-900">Reservation History</h3>
                    <span class="text-xs text-gray-400">{{ $reservations->total() }} total</span>
                </div>
                <div class="divide-y divide-gray-50">
                    @forelse($reservations as $res)
                        <div class="flex items-center gap-4 px-6 py-4 hover:bg-gray-50 transition-colors">
                            <div class="w-10 h-10 rounded-lg bg-hotel-100 flex items-center justify-center flex-shrink-0">
                                <span class="text-xs font-bold text-hotel-700">{{ $res->room->room_number }}</span>
                            </div>
                            <div class="flex-1">
                                <div class="flex items-center gap-2">
                                    <p class="text-sm font-medium text-gray-900">{{ $res->reservation_number }}</p>
                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium {{ $res->status_badge }}">
                                {{ ucfirst(str_replace('_', ' ', $res->status)) }}
                            </span>
                                </div>
                                <p class="text-xs text-gray-400">{{ $res->check_in_date->format('M d') }} → {{ $res->check_out_date->format('M d, Y') }} · {{ $res->nights }} nights · Room {{ $res->room->type }}</p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-semibold text-gray-900">${{ number_format($res->total_amount, 0) }}</p>
                                <span class="text-xs {{ $res->payment_status === 'paid' ? 'text-green-600' : 'text-yellow-600' }}">{{ ucfirst($res->payment_status) }}</span>
                            </div>
                            <a href="{{ route('reservations.show', $res) }}" class="text-xs text-hotel-600 hover:underline ml-2">View</a>
                        </div>
                    @empty
                        <div class="px-6 py-12 text-center text-gray-400">
                            <p>No reservations yet</p>
                            <a href="{{ route('reservations.create', ['guest_id' => $guest->id]) }}" class="text-hotel-600 hover:underline text-sm mt-1 inline-block">Create first reservation</a>
                        </div>
                    @endforelse
                </div>
                <div class="px-6 py-4">{{ $reservations->links() }}</div>
            </div>
        </div>
    </div>
@endsection
