@extends('layouts.app')
@section('page-title', 'Dashboard')

@section('header-actions')
    <a href="{{ route('reservations.create') }}"
       class="inline-flex items-center gap-2 bg-hotel-600 hover:bg-hotel-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
        </svg>
        New Reservation
    </a>
@endsection

@section('content')
    <!-- Stats Grid -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <div class="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm text-gray-500">Total Rooms</span>
                <div class="w-8 h-8 bg-hotel-100 rounded-lg flex items-center justify-center">
                    <svg class="w-4 h-4 text-hotel-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-bold text-gray-900">{{ $totalRooms }}</p>
            <p class="text-xs text-green-600 mt-1">{{ $availableRooms }} available</p>
        </div>

        <div class="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm text-gray-500">Occupied</span>
                <div class="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                    <svg class="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-bold text-gray-900">{{ $occupiedRooms }}</p>
            <p class="text-xs text-gray-400 mt-1">{{ $totalRooms > 0 ? round($occupiedRooms / $totalRooms * 100) : 0 }}% occupancy</p>
        </div>

        <div class="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm text-gray-500">Today's Activity</span>
                <div class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg class="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-bold text-gray-900">{{ $checkInsToday + $checkOutsToday }}</p>
            <p class="text-xs text-gray-400 mt-1">{{ $checkInsToday }} in · {{ $checkOutsToday }} out</p>
        </div>

        <div class="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
            <div class="flex items-center justify-between mb-3">
                <span class="text-sm text-gray-500">Revenue (Month)</span>
                <div class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-bold text-gray-900">${{ number_format($revenueThisMonth, 0) }}</p>
            <p class="text-xs text-gray-400 mt-1">{{ now()->format('F Y') }}</p>
        </div>
    </div>

    <!-- Main Grid -->
    <div class="grid grid-cols-3 gap-6">
        <!-- Active Reservations -->
        <div class="col-span-2 bg-white rounded-xl border border-gray-100 shadow-sm">
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-100">
                <h2 class="font-semibold text-gray-900">Active Reservations</h2>
                <a href="{{ route('reservations.index', ['status' => 'checked_in']) }}" class="text-xs text-hotel-600 hover:underline">View all</a>
            </div>
            <div class="divide-y divide-gray-50">
                @forelse($activeReservations as $res)
                    <div class="flex items-center gap-4 px-6 py-3 hover:bg-gray-50 transition-colors">
                        <div class="w-9 h-9 rounded-lg bg-hotel-100 flex items-center justify-center flex-shrink-0">
                            <span class="text-xs font-bold text-hotel-700">{{ $res->room->room_number }}</span>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium text-gray-900">{{ $res->guest->full_name }}</p>
                            <p class="text-xs text-gray-400">{{ $res->check_in_date->format('M d') }} → {{ $res->check_out_date->format('M d') }} · {{ $res->nights }} nights</p>
                        </div>
                        <div class="text-right">
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium {{ $res->status_badge }}">
                        {{ ucfirst(str_replace('_', ' ', $res->status)) }}
                    </span>
                            <p class="text-xs text-gray-400 mt-0.5">${{ number_format($res->total_amount, 0) }}</p>
                        </div>
                    </div>
                @empty
                    <div class="px-6 py-8 text-center text-gray-400 text-sm">No active reservations</div>
                @endforelse
            </div>
        </div>

        <!-- Right Column -->
        <div class="space-y-6">
            <!-- Upcoming Check-ins -->
            <div class="bg-white rounded-xl border border-gray-100 shadow-sm">
                <div class="px-5 py-4 border-b border-gray-100">
                    <h2 class="font-semibold text-gray-900 text-sm">Upcoming Check-ins</h2>
                </div>
                <div class="divide-y divide-gray-50">
                    @forelse($upcomingCheckIns as $res)
                        <div class="px-5 py-3">
                            <p class="text-sm font-medium text-gray-900">{{ $res->guest->full_name }}</p>
                            <p class="text-xs text-gray-400">Room {{ $res->room->room_number }} · {{ $res->check_in_date->format('M d') }}</p>
                        </div>
                    @empty
                        <div class="px-5 py-4 text-center text-gray-400 text-xs">No upcoming check-ins</div>
                    @endforelse
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
                <h2 class="font-semibold text-gray-900 text-sm mb-4">Quick Actions</h2>
                <div class="space-y-2">
                    <a href="{{ route('reservations.create') }}" class="flex items-center gap-3 text-sm text-gray-700 hover:text-hotel-700 py-1 transition-colors">
                        <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                        New Reservation
                    </a>
                    <a href="{{ route('guests.create') }}" class="flex items-center gap-3 text-sm text-gray-700 hover:text-hotel-700 py-1 transition-colors">
                        <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>
                        Add Guest
                    </a>
                    <a href="{{ route('rooms.create') }}" class="flex items-center gap-3 text-sm text-gray-700 hover:text-hotel-700 py-1 transition-colors">
                        <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                        Add Room
                    </a>
                    <a href="{{ route('reservations.index', ['status' => 'pending']) }}" class="flex items-center gap-3 text-sm text-gray-700 hover:text-hotel-700 py-1 transition-colors">
                        <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        Pending Reservations
                    </a>
                </div>
            </div>
        </div>
    </div>
@endsection
