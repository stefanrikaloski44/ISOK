@extends('layouts.app')
@section('page-title', 'New Reservation')
@section('breadcrumbs')
    <a href="{{ route('reservations.index') }}" class="hover:text-gray-600">Reservations</a> / New
@endsection

@section('content')
    <div class="max-w-2xl">
        <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-6">
            <form method="POST" action="{{ route('reservations.store') }}" id="reservationForm" class="space-y-5">
                @csrf

                <!-- Guest Selection -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Guest <span class="text-red-500">*</span></label>
                    <select name="guest_id" id="guestSelect" required
                            class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400 @error('guest_id') border-red-400 @enderror">
                        <option value="">Select a guest...</option>
                        @foreach($guests as $guest)
                            <option value="{{ $guest->id }}"
                                {{ old('guest_id', request('guest_id')) == $guest->id ? 'selected' : '' }}>
                                {{ $guest->full_name }} — {{ $guest->email }}
                            </option>
                        @endforeach
                    </select>
                    @error('guest_id')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
                    <p class="text-xs text-gray-400 mt-1">
                        Guest not found?
                        <a href="{{ route('guests.create') }}" target="_blank" class="text-hotel-600 hover:underline">Add new guest</a>
                    </p>
                </div>

                <!-- Room Selection -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Room <span class="text-red-500">*</span></label>
                    <select name="room_id" id="roomSelect" required
                            class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400 @error('room_id') border-red-400 @enderror">
                        <option value="">Select a room...</option>
                        @foreach($rooms as $room)
                            <option value="{{ $room->id }}"
                                    data-price="{{ $room->price_per_night }}"
                                    data-capacity="{{ $room->capacity }}"
                                {{ old('room_id', request('room_id')) == $room->id ? 'selected' : '' }}>
                                Room {{ $room->room_number }} — {{ ucfirst($room->type) }} — ${{ $room->price_per_night }}/night — {{ $room->status }}
                            </option>
                        @endforeach
                    </select>
                    @error('room_id')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
                </div>

                <!-- Dates -->
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Check-in Date <span class="text-red-500">*</span></label>
                        <input type="date" name="check_in_date" id="checkIn"
                               value="{{ old('check_in_date', date('Y-m-d')) }}" required
                               min="{{ date('Y-m-d') }}"
                               class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400">
                        @error('check_in_date')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Check-out Date <span class="text-red-500">*</span></label>
                        <input type="date" name="check_out_date" id="checkOut"
                               value="{{ old('check_out_date', date('Y-m-d', strtotime('+1 day'))) }}" required
                               class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400">
                        @error('check_out_date')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Number of Guests <span class="text-red-500">*</span></label>
                        <input type="number" name="guests_count" id="guestsCount"
                               value="{{ old('guests_count', 1) }}" min="1" required
                               class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Discount ($)</label>
                        <input type="number" name="discount" id="discount"
                               value="{{ old('discount', 0) }}" step="0.01" min="0"
                               class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400">
                    </div>
                </div>

                <!-- Price Summary -->
                <div id="priceSummary" class="bg-hotel-50 rounded-lg p-4 text-sm hidden">
                    <div class="flex justify-between text-gray-600 mb-1">
                        <span id="nightsLabel">0 nights × $0</span>
                        <span id="subtotalLabel">$0</span>
                    </div>
                    <div class="flex justify-between text-gray-600 mb-2">
                        <span>Discount</span>
                        <span id="discountLabel" class="text-green-600">-$0</span>
                    </div>
                    <div class="flex justify-between font-bold text-gray-900 pt-2 border-t border-hotel-200">
                        <span>Total</span>
                        <span id="totalLabel">$0</span>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Payment Method</label>
                    <select name="payment_method" class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400">
                        <option value="">Not specified</option>
                        @foreach(\App\Models\Reservation::paymentMethods() as $method)
                            <option value="{{ $method }}" {{ old('payment_method') == $method ? 'selected' : '' }}>{{ ucwords(str_replace('_', ' ', $method)) }}</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Special Requests</label>
                    <textarea name="special_requests" rows="2"
                              class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400"
                              placeholder="Any special requests from the guest...">{{ old('special_requests') }}</textarea>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Internal Notes</label>
                    <textarea name="notes" rows="2"
                              class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-hotel-400"
                              placeholder="Staff notes (not visible to guest)...">{{ old('notes') }}</textarea>
                </div>

                <div class="flex items-center gap-3 pt-2 border-t border-gray-100">
                    <button type="submit" class="bg-hotel-600 hover:bg-hotel-700 text-white text-sm font-medium px-6 py-2 rounded-lg transition-colors">
                        Create Reservation
                    </button>
                    <a href="{{ route('reservations.index') }}" class="text-gray-500 hover:text-gray-700 text-sm">Cancel</a>
                </div>
            </form>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        function updateSummary() {
            const roomSelect = document.getElementById('roomSelect');
            const selectedOption = roomSelect.options[roomSelect.selectedIndex];
            const checkIn = document.getElementById('checkIn').value;
            const checkOut = document.getElementById('checkOut').value;
            const discount = parseFloat(document.getElementById('discount').value) || 0;
            const summary = document.getElementById('priceSummary');

            if (!selectedOption.value || !checkIn || !checkOut) {
                summary.classList.add('hidden');
                return;
            }

            const pricePerNight = parseFloat(selectedOption.dataset.price) || 0;
            const d1 = new Date(checkIn), d2 = new Date(checkOut);
            const nights = Math.max(0, Math.round((d2 - d1) / (1000 * 60 * 60 * 24)));
            const subtotal = pricePerNight * nights;
            const total = Math.max(0, subtotal - discount);

            document.getElementById('nightsLabel').textContent = `${nights} night(s) × $${pricePerNight}`;
            document.getElementById('subtotalLabel').textContent = `$${subtotal.toFixed(2)}`;
            document.getElementById('discountLabel').textContent = `-$${discount.toFixed(2)}`;
            document.getElementById('totalLabel').textContent = `$${total.toFixed(2)}`;
            summary.classList.remove('hidden');
        }

        ['roomSelect','checkIn','checkOut','discount'].forEach(id => {
            document.getElementById(id)?.addEventListener('change', updateSummary);
            document.getElementById(id)?.addEventListener('input', updateSummary);
        });

        updateSummary();
    </script>
@endpush
