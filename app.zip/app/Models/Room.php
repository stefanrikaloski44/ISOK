<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Room extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'room_number', 'type', 'description', 'price_per_night',
        'capacity', 'floor', 'status', 'amenities', 'image',
    ];

    protected $casts = [
        'amenities' => 'array',
        'price_per_night' => 'decimal:2',
    ];

    // Relationships
    public function reservations()
    {
        return $this->hasMany(Reservation::class);
    }

    public function activeReservation()
    {
        return $this->hasOne(Reservation::class)
            ->whereIn('status', ['confirmed', 'checked_in'])
            ->latest();
    }

    // Scopes
    public function scopeAvailable($query)
    {
        return $query->where('status', 'available');
    }

    public function scopeOfType($query, $type)
    {
        return $query->where('type', $type);
    }

    public function scopeAvailableForDates($query, $checkIn, $checkOut)
    {
        return $query->where('status', '!=', 'maintenance')
            ->whereDoesntHave('reservations', function ($q) use ($checkIn, $checkOut) {
                $q->whereNotIn('status', ['cancelled', 'no_show'])
                    ->where(function ($q2) use ($checkIn, $checkOut) {
                        $q2->whereBetween('check_in_date', [$checkIn, $checkOut])
                            ->orWhereBetween('check_out_date', [$checkIn, $checkOut])
                            ->orWhere(function ($q3) use ($checkIn, $checkOut) {
                                $q3->where('check_in_date', '<=', $checkIn)
                                    ->where('check_out_date', '>=', $checkOut);
                            });
                    });
            });
    }

    // Helpers
    public function getStatusBadgeAttribute(): string
    {
        return match($this->status) {
            'available'   => 'bg-green-100 text-green-800',
            'occupied'    => 'bg-red-100 text-red-800',
            'maintenance' => 'bg-yellow-100 text-yellow-800',
            'cleaning'    => 'bg-blue-100 text-blue-800',
            default       => 'bg-gray-100 text-gray-800',
        };
    }

    public static function types(): array
    {
        return ['single', 'double', 'twin', 'suite', 'deluxe', 'presidential'];
    }

    public static function statuses(): array
    {
        return ['available', 'occupied', 'maintenance', 'cleaning'];
    }

    public static function amenitiesList(): array
    {
        return ['WiFi', 'TV', 'Air Conditioning', 'Mini Bar', 'Safe', 'Balcony', 'Bathtub', 'Jacuzzi', 'Sea View', 'City View', 'Kitchen', 'Parking'];
    }
}
