<?php

namespace App\Http\Controllers;

use App\Models\Guest;
use Illuminate\Http\Request;

class GuestController extends Controller
{
    public function index(Request $request)
    {
        $query = Guest::withCount('reservations');

        if ($request->search) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('first_name', 'like', "%{$search}%")
                    ->orWhere('last_name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%")
                    ->orWhere('phone', 'like', "%{$search}%")
                    ->orWhere('id_number', 'like', "%{$search}%");
            });
        }

        $guests = $query->orderBy('last_name')->paginate(15)->withQueryString();

        return view('guests.index', compact('guests'));
    }

    public function create()
    {
        return view('guests.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'first_name'    => 'required|string|max:100',
            'last_name'     => 'required|string|max:100',
            'email'         => 'required|email|unique:guests',
            'phone'         => 'nullable|string|max:30',
            'id_number'     => 'nullable|string|max:50',
            'nationality'   => 'nullable|string|max:100',
            'date_of_birth' => 'nullable|date|before:today',
            'address'       => 'nullable|string',
            'city'          => 'nullable|string|max:100',
            'country'       => 'nullable|string|max:100',
            'notes'         => 'nullable|string',
        ]);

        $guest = Guest::create($data);

        return redirect()->route('guests.show', $guest)
            ->with('success', 'Guest created successfully!');
    }

    public function show(Guest $guest)
    {
        $guest->loadCount('reservations');
        $reservations = $guest->reservations()
            ->with('room')
            ->orderBy('check_in_date', 'desc')
            ->paginate(10);

        return view('guests.show', compact('guest', 'reservations'));
    }

    public function edit(Guest $guest)
    {
        return view('guests.edit', compact('guest'));
    }

    public function update(Request $request, Guest $guest)
    {
        $data = $request->validate([
            'first_name'    => 'required|string|max:100',
            'last_name'     => 'required|string|max:100',
            'email'         => 'required|email|unique:guests,email,' . $guest->id,
            'phone'         => 'nullable|string|max:30',
            'id_number'     => 'nullable|string|max:50',
            'nationality'   => 'nullable|string|max:100',
            'date_of_birth' => 'nullable|date|before:today',
            'address'       => 'nullable|string',
            'city'          => 'nullable|string|max:100',
            'country'       => 'nullable|string|max:100',
            'notes'         => 'nullable|string',
        ]);

        $guest->update($data);

        return redirect()->route('guests.show', $guest)
            ->with('success', 'Guest updated successfully!');
    }

    public function destroy(Guest $guest)
    {
        if ($guest->reservations()->whereIn('status', ['confirmed', 'checked_in'])->exists()) {
            return back()->with('error', 'Cannot delete a guest with active reservations.');
        }
        $guest->delete();
        return redirect()->route('guests.index')
            ->with('success', 'Guest deleted successfully!');
    }

    public function search(Request $request)
    {
        $guests = Guest::where('first_name', 'like', "%{$request->q}%")
            ->orWhere('last_name', 'like', "%{$request->q}%")
            ->orWhere('email', 'like', "%{$request->q}%")
            ->limit(10)
            ->get(['id', 'first_name', 'last_name', 'email', 'phone']);

        return response()->json($guests);
    }
}
