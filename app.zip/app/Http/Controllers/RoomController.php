<?php

namespace App\Http\Controllers;

use App\Models\Room;
use Illuminate\Http\Request;

class RoomController extends Controller
{
    public function index(Request $request)
    {
        $query = Room::query();

        if ($request->search) {
            $query->where('room_number', 'like', "%{$request->search}%")
                ->orWhere('type', 'like', "%{$request->search}%");
        }
        if ($request->type) {
            $query->where('type', $request->type);
        }
        if ($request->status) {
            $query->where('status', $request->status);
        }

        $rooms = $query->orderBy('room_number')->paginate(12)->withQueryString();

        return view('rooms.index', compact('rooms'));
    }

    public function create()
    {
        return view('rooms.create', [
            'types'     => Room::types(),
            'statuses'  => Room::statuses(),
            'amenities' => Room::amenitiesList(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'room_number'     => 'required|string|unique:rooms',
            'type'            => 'required|in:' . implode(',', Room::types()),
            'description'     => 'nullable|string',
            'price_per_night' => 'required|numeric|min:0',
            'capacity'        => 'required|integer|min:1|max:20',
            'floor'           => 'required|integer|min:0',
            'status'          => 'required|in:' . implode(',', Room::statuses()),
            'amenities'       => 'nullable|array',
            'amenities.*'     => 'string',
        ]);

        Room::create($data);

        return redirect()->route('rooms.index')
            ->with('success', "Room {$data['room_number']} created successfully!");
    }

    public function show(Room $room)
    {
        $room->load(['reservations.guest' => function ($q) {
            $q->orderBy('check_in_date', 'desc');
        }]);
        $upcomingReservations = $room->reservations()
            ->whereIn('status', ['pending', 'confirmed'])
            ->with('guest')
            ->orderBy('check_in_date')
            ->get();
        $recentHistory = $room->reservations()
            ->whereIn('status', ['checked_out', 'cancelled'])
            ->with('guest')
            ->orderBy('check_out_date', 'desc')
            ->take(10)
            ->get();

        return view('rooms.show', compact('room', 'upcomingReservations', 'recentHistory'));
    }

    public function edit(Room $room)
    {
        return view('rooms.edit', [
            'room'      => $room,
            'types'     => Room::types(),
            'statuses'  => Room::statuses(),
            'amenities' => Room::amenitiesList(),
        ]);
    }

    public function update(Request $request, Room $room)
    {
        $data = $request->validate([
            'room_number'     => 'required|string|unique:rooms,room_number,' . $room->id,
            'type'            => 'required|in:' . implode(',', Room::types()),
            'description'     => 'nullable|string',
            'price_per_night' => 'required|numeric|min:0',
            'capacity'        => 'required|integer|min:1|max:20',
            'floor'           => 'required|integer|min:0',
            'status'          => 'required|in:' . implode(',', Room::statuses()),
            'amenities'       => 'nullable|array',
            'amenities.*'     => 'string',
        ]);

        $room->update($data);

        return redirect()->route('rooms.show', $room)
            ->with('success', 'Room updated successfully!');
    }

    public function destroy(Room $room)
    {
        if ($room->reservations()->whereIn('status', ['confirmed', 'checked_in'])->exists()) {
            return back()->with('error', 'Cannot delete a room with active reservations.');
        }
        $room->delete();
        return redirect()->route('rooms.index')
            ->with('success', 'Room deleted successfully!');
    }
}
