<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\RoomController;
use App\Http\Controllers\GuestController;
use App\Http\Controllers\ReservationController;
use App\Http\Controllers\PublicController;

Route::get('/', [PublicController::class, 'home'])->name('home');
Route::get('/rooms', [PublicController::class, 'rooms'])->name('public.rooms');
Route::get('/rooms/{room}', [PublicController::class, 'room'])->name('public.room');
Route::get('/book/{room}', [PublicController::class, 'bookingForm'])->name('public.book');
Route::post('/book/{room}', [PublicController::class, 'bookingStore'])->name('public.book.store');
Route::get('/booking/confirmation/{reservation}', [PublicController::class, 'confirmation'])->name('public.confirmation');

Route::middleware(['auth'])->group(function () {
    Route::get('/my-reservations', [PublicController::class, 'myReservations'])->name('my.reservations');
});

Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::resource('rooms', RoomController::class);
    Route::get('/guests/search', [GuestController::class, 'search'])->name('guests.search');
    Route::resource('guests', GuestController::class);
    Route::resource('reservations', ReservationController::class);
    Route::post('/reservations/{reservation}/check-in', [ReservationController::class, 'checkIn'])->name('reservations.check-in');
    Route::post('/reservations/{reservation}/check-out', [ReservationController::class, 'checkOut'])->name('reservations.check-out');
    Route::post('/reservations/{reservation}/cancel', [ReservationController::class, 'cancel'])->name('reservations.cancel');
    Route::post('/reservations/{reservation}/payment', [ReservationController::class, 'addPayment'])->name('reservations.payment');
});

require __DIR__.'/auth.php';
